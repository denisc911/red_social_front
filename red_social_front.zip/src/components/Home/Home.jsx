import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      {/* Aquí agregarás la lógica para mostrar publicaciones */}
    </div>
  );
};

export default Home;
