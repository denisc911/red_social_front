const NotFound = () => {
    return <div>404 Page not found</div>
 }
 
 export default NotFound
 